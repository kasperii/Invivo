package com.orpheusdroid.screenrecorder.beaconTracker;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.util.Log;

import com.orpheusdroid.screenrecorder.FloatingControlService;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconConsumer;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;

import java.util.Collection;

public class RangingService extends Service implements BeaconConsumer {
	private BeaconManager beaconManager = BeaconManager.getInstanceForApplication(this);
    protected static final String TAG = "RangingService";





	@Override
	public void onCreate() {
		super.onCreate();
	}


	@Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    //Imported method from example
    @Override
    public void onBeaconServiceConnect() {

        RangeNotifier rangeNotifier = new RangeNotifier() {
           @Override
           public void didRangeBeaconsInRegion(Collection<Beacon> beacons, Region region) {
              if (beacons.size() > 0) {
                  Log.d(TAG, "didRangeBeaconsInRegion called with beacon count:  "+beacons.size());
                  Beacon firstBeacon = beacons.iterator().next();
                  //this method is not available anymore - better display updates another way
                  //logToDisplay("The first beacon " + firstBeacon.toString() + " is about " + firstBeacon.getDistance() + " meters away.");
              }
           }

        };
        try {
            beaconManager.startRangingBeaconsInRegion(new Region("myRangingUniqueId", null, null, null));
            beaconManager.addRangeNotifier(rangeNotifier);
            beaconManager.startRangingBeaconsInRegion(new Region("myRangingUniqueId", null, null, null));
            beaconManager.addRangeNotifier(rangeNotifier);
        } catch (RemoteException e) {   }
    }
    //This code did work when it was an activity - now as a service this does not have a view to edit.
//    private void logToDisplay(final String line) {
//        runOnUiThread(new Runnable() {
//            public void run() {
//                EditText editText = (EditText)RangingService.this.findViewById(R.id.rangingText);
//                editText.append(line+"\n");
//            }
//        });
//    }



}
