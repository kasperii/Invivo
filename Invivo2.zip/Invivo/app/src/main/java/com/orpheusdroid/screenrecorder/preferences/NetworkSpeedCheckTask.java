package com.orpheusdroid.screenrecorder.preferences;

public class NetworkSpeedCheckTask {
}
